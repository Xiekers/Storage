goagent 3.2.3 正式版下载 [http://git.io/goa](https://nodeload.github.com/goagent/goagent/legacy.zip/3.0)

## 最近更新
* [1122 否] 3.2.3 正式版，修复 MacOSX/Linux 平台 CPU 100% 的问题；托盘图标支持设置ADSL拨号网络代理(注意：拨号网络请使用英文名称）。

## 讨论区
* https://code.google.com/p/goagent/issues/list

## 文档
* 简易教程 https://github.com/goagent/goagent/blob/wiki/SimpleGuide.md
* 图文教程 https://github.com/goagent/goagent/blob/wiki/InstallGuide.md
* 常见问题 https://github.com/goagent/goagent/blob/wiki/FAQ.md
* 配置介绍 https://github.com/goagent/goagent/blob/wiki/ConfigIntroduce.md
* 五毛观止 https://github.com/goagent/goagent/blob/wiki/SpamList.md
* 更新历史 https://github.com/goagent/goagent/blob/wiki/History.md

## 代码
 * proxy.py https://github.com/goagent/goagent
 * python27.exe https://github.com/goagent/pybuild
 * goagent.exe https://github.com/goagent/taskbar
